import { bootstrap } from 'angular2/platform/browser';

// main component
import { AppComponent }
  from './app.component';

bootstrap(AppComponent);


