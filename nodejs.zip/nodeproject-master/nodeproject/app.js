var aloha = 'Aloha Variables';
console.log(aloha);